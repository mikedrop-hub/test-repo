from setuptools import setup
setup(
    name="my-expense-app",
    version="1.0",
    scripts=["app.py"],
    packages=[],
    author="mikedrop-hub",
    author_email="michael@example.com",
    description="A simple expense tracking application",
    long_description="LOOO000oooo........nger description",
)